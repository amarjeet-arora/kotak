package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.User;
import com.service.AppService;
@Controller
@RequestMapping("/mainapp")
public class GetController {

	@Autowired
	private AppService appService;

	 
@GetMapping("/login")
	public String login() {
		return "login";
	}

	 
	 @GetMapping("/registration")
	public String registration() {
		return "registration";
	}

	 
	 @GetMapping("/loadusers")
	 @ResponseBody
	 public List<User> loadAllUsers(){
		 
		return appService.loadUsers();
		 
		 
		 
	 }
	 
	 @GetMapping("/loaduser/{name}")
	 @ResponseBody
	 public String loadAllUser(@PathVariable("name")String unme){
		 
	 
		 if(appService.findUser(unme)) {
			 return "user found";
		 }
		 
		 return "user is not found";
	 }
	 
	 @GetMapping("/deleteuser/{name}")
	 @ResponseBody
	 public String deleteUser(@PathVariable("name")String uname) {
		 if(appService.deleteUser(uname)) {
			 return "user deleted";
		 }
		 return "user is not found";
	 }
	 
	 
	 
	 
}
