package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.AppService;

@RestController
@RequestMapping("/mainapp")
public class AppController {

	@Autowired
	private AppService appService;

	 
	 @PostMapping("/login")
	public String loginValid(@RequestParam("uname") String name, @RequestParam("pass") String pass) {

		if (appService.userValid(name, pass)) {
			return " user is successful";
		}

		return " user is failed";
	}

	 
	 @PostMapping("/registration")
	public String registrationValid(@RequestParam("uname") String name, @RequestParam("pass") String pass,
			@RequestParam("email") String email, @RequestParam("city") String city) {

		if (appService.addUser(name, email, pass, city)) {
			return " user added successfully";
		}

		return " user is not added";
	}

}
