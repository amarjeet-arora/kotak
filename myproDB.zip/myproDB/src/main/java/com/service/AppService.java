package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MyRepo;
import com.model.User;

@Service
public class AppService {
	
	@Autowired
	private MyRepo myRepo;

	ArrayList<User> al = new ArrayList<>();

	public boolean addUser(String uname, String email, String password, String city) {

		//al.add(new User(uname, email, password, city));

		myRepo.save(new User(uname, email, password, city));
		
		
		//System.out.println(al);
		return true;

	}

	public boolean userValid(String uname, String pass) {
		if (uname.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;

	}
	
	public List<User> loadUsers(){
		return al;
	}
	public boolean findUser(String name) {
		
		for(User user: al) {
			if(user.getName().equals(name)) {
				System.out.println(user.getName() + " is found");
				return true;
				
			}
			
		}
		return false;
		
		
		
	}
	public boolean deleteUser(String name) {
		
		for(User user: al) {
			if(user.getName().equals(name)) {
				System.out.println(user.getName() + " is found");
				int id= al.indexOf(name);
				al.remove(id);
				return true;
				
			}
			
		}
		return false;
		
		
		
	}
	
	
	
	
	
	
	

}
